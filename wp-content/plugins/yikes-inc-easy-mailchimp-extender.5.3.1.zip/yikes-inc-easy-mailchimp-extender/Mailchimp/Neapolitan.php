<?php

class Mailchimp_Neapolitan {
    public function __construct(wpyksMCAPI $master) {
        $this->master = $master;
    }

}


